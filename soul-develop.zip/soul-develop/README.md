# soul
SOUL Robotics Software Platform

## Building

### Dependencies
 - Ubuntu 18.04 or higher
 - CMake 3.10 or higher
 - gcc 7 or higher
 - Boost system 1.65 or higher
 - Boost filesystem 1.65 or higher
 - OpenCV 4.0.1 or higher
 - Boost ProgramOptions 1.65 or higher

To install dependencies on your Ubuntu system:
 ```bash
sudo add-apt-repository ppa:patrick-salecker/opencv
sudo apt-get update
sudo apt install build-essential
sudo apt install libboost-system1.65-dev libboost-filesystem1.65-dev libboost-program-options1.65-dev
sudo apt install libopencv-dev
 ```

#### Recommended packages

It is recommended that you also install ```clang-tools``` for additional static analysis checking.
```
sudo apt install clang-tools
```

This gives you access to to the ```scan-build``` tool that lets you run your code through the clang static analyzer if you choose.


### Compiling

The project uses CMake for its build system. The minimum target cmake version is 3.10, which is what Ubuntu 18.04 has installed on the system.

The target C++ standard has C++17 as its placeholder, but gcc 7 (found on Ubuntu 18.04) will not actually have all C++17 functionality. Practically this means, you can use C++14 features and some C++17 features which are flagged as 'experimental' even though they have made it into the standard (you need a more recent compiler for this to be default though).

#### Release version
```
rm -rf build && mkdir build && cd build
cmake ..
make
```

#### Debug version

Debug mode will define the flag ```HR_DEBUG``` in the C preprocessor, which will disable the ```private``` attribute in most places, and enable extra debug mode tests.

The sanitizer library ```libasan``` will also be enabled under debug mode with address sanitization checks turned on.

```
rm -rf build && mkdir build && cd build
cmake -DCMAKE_BUILD_TYPE=Debug ..
make
```

#### With tests
```
rm -rf build && mkdir build && cd build
cmake -DBUILD_TESTS=1 ..
make
```

You can mix and match tests and build types.  Some tests will only be compiled and run in Debug build type.

### Running tests
In the build directory run:
```
make test
```
or
```
ctest
```

To get verbose output, run
```
ctest -V
```

### Build with clang static analysis checking
If you installed ```clang-tools``` you have the option of doing further static analysis by invoking ```scan-build``` during the make process with
```
scan-build make
```

## Running the modules

### Sense (perception) manager

For now most of the functionality is implemented in the unit tests, so you can spin those up to test it.  There is a standalone ```soul_sense_manager``` binary that will exist in the ```build/sense``` directory. You can call it with ```-h``` to see what command line arguments are accepted.  For now it just spins up the perception manager, and executes the run() method, which will sit there and do nothing.

## Directory structure
```
soul
|  README.md             # This file
|  .clang-format         # Clang C++ format style file
|  CMakeLists.txt        # CMake build file
|  LICENSE               # Hanson Robotics licence file
|
└──third_party/          # Third party library dependencies
|
└──messaging/            # SOUL messaging system (components can specialise this)
|  └──include/           # Definitions and other headers
|  └──src/               # C++ source files
|  └──tests/             # Unit tests=
|
└──plugins/              # SOUL generic plugin system
|  └──include/           # Definitions and other headers
|  └──src/               # C++ source files
|  └──tests/             # Unit tests
|
└──sense/                # SOUL Sense (Perception)
|  └──include/           # Definitions and other headers
|  └──src/               # C++ source files
|  └──tests/             # Unit tests
|
```